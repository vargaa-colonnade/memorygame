import { createSelector } from "reselect";
import type { RootState } from "../store";

const selectUserReducer = (state: RootState) => state.card;

export const selectCurrentCard = (state: RootState) => state.card.currentCard;

export const selectCurrentUserAuthOpen = createSelector(
  [selectUserReducer],
  (user) => user.isComponentVisible
);
