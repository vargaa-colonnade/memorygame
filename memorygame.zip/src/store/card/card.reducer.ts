import { createSlice } from "@reduxjs/toolkit";

const INITIAL_STATE = {
  currentCard: null,
  isComponentVisible: false,
  test: { a: 1 },
};

export const cardSlice = createSlice({
  name: "card",
  initialState: INITIAL_STATE,
  reducers: {
    setCurrentCard(state, action) {
      state.currentCard = action.payload;
    },
    setIsComponentVisible(state, action) {
      state.isComponentVisible = action.payload;
    },
  },
});

export const { setCurrentCard, setIsComponentVisible } = cardSlice.actions;

export const cardReducer = cardSlice.reducer;
